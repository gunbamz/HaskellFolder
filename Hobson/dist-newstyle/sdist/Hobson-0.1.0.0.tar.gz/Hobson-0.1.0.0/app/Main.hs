module Main where
--import Tutorial2
--import Tutorial3
import Tutorial10

main :: IO ()
main = putStrLn "Hello, Haskell!"
